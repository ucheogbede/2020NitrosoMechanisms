####  query fraction is length of overlap divided by number of genes scored significant in screen
####  geneSet is length of genes in the geneSet 
####  overlap is length of intersect
####  bgRate round rate is length geneSets /total number of rows in unigene set (matrix)
####  foldenrichment query fraction /bgRate



NONSPECIFIC.TERMS <- list(mf=c("MOLECULAR_FUNCTION", "BINDING", "CATALYTIC ACTIVITY"),
                          cc=c("CELL", "CELL CORTEX PART", "CELL DIVISION SITE PART", "CELL FRACTION", "CELL PART", "CELL PERIPHERY", "CELL PROJECTION PART", "CELL WALL PART", "CELLULAR_COMPONENT", "CHROMOSOMAL PART", "CYTOPLASMIC PART", "CYTOPLASMIC VESICLE PART", "CYTOSKELETAL PART", "CYTOSOLIC PART", "ENDOPLASMIC RETICULUM PART", "ENDOSOMAL PART", "EXTERNAL ENCAPSULATING STRUCTURE", "EXTERNAL ENCAPSULATING STRUCTURE PART", "EXTRINSIC TO MEMBRANE", "GOLGI APPARATUS PART", "INSOLUBLE FRACTION", "INTEGRAL TO MEMBRANE", "INTEGRAL TO MEMBRANE OF MEMBRANE FRACTION", "INTRACELLULAR", "INTRACELLULAR ORGANELLE", "INTRACELLULAR ORGANELLE LUMEN", "INTRACELLULAR ORGANELLE PART", "INTRACELLULAR PART", "INTRACELLULAR MEMBRANE-BOUNDED ORGANELLE", "INTRACELLULAR NON-MEMBRANE-BOUNDED ORGANELLE", "INTRINSIC TO MEMBRANE", "MEMBRANE", "MEMBRANE-BOUNDED ORGANELLE", "MEMBRANE-ENCLOSED LUMEN", "MEMBRANE FRACTION", "MEMBRANE PART", "MICROBODY PART", "MICROTUBULE ORGANIZING CENTER PART", "MITOCHONDRIAL MEMBRANE PART", "MITOCHONDRIAL PART", "NON-MEMBRANE-BOUNDED ORGANELLE", "NUCLEAR CHROMOSOME PART", "NUCLEAR MEMBRANE PART", "NUCLEAR PART", "NUCLEOLAR PART", "NUCLEOPLASM PART", "ORGANELLE", "ORGANELLE INNER MEMBRANE", "ORGANELLE LUMEN", "ORGANELLE MEMBRANE", "ORGANELLE OUTER MEMBRANE", "ORGANELLE PART", "ORGANELLE SUBCOMPARTMENT", "PERIPHERAL TO MEMBRANE OF MEMBRANE FRACTION", "PEROXISOMAL PART", "PLASMA MEMBRANE ENRICHED FRACTION", "PLASMA MEMBRANE PART", "VACUOLAR PART", "VESICULAR FRACTION"),
                          bp=c("POSITIVE REGULATION OF MACROMOLECULE METABOLIC PROCESS", "REGULATION OF CELLULAR COMPONENT ORGANIZATION", "POSITIVE REGULATION OF METABOLIC PROCESS", "POSITIVE REGULATION OF CELLULAR METABOLIC PROCESS", "POSITIVE REGULATION OF CELLULAR PROCESS", "REGULATION OF CELLULAR PROCESS", "CELLULAR NITROGEN COMPOUND BIOSYNTHETIC PROCESS", "POSITIVE REGULATION OF NITROGEN COMPOUND METABOLIC PROCESS", "REGULATION OF CATALYTIC ACTIVITY", "POSITIVE REGULATION OF CATALYTIC ACTIVITY", "REGULATION OF MOLECULAR FUNCTION", "POSITIVE REGULATION OF CELLULAR COMPONENT ORGANIZATION", "REGULATION OF ORGANELLE ORGANIZATION", "POSITIVE REGULATION OF CATABOLIC PROCESS", "POSITIVE REGULATION OF CELLULAR CATABOLIC PROCESS", "POSITIVE REGULATION OF MOLECULAR FUNCTION", "REGULATION OF CATABOLIC PROCESS", "REGULATION OF CELLULAR CATABOLIC PROCESS", "CELLULAR RESPONSE TO CHEMICAL STIMULUS", "CELLULAR RESPONSE TO ORGANIC SUBSTANCE", "POSITIVE REGULATION OF BIOSYNTHETIC PROCESS", "POSITIVE REGULATION OF CELLULAR BIOSYNTHETIC PROCESS", "POSITIVE REGULATION OF MACROMOLECULE BIOSYNTHETIC PROCESS", "CELLULAR CARBOHYDRATE METABOLIC PROCESS", "REGULATION OF CELLULAR PROTEIN METABOLIC PROCESS", "REGULATION OF PROTEIN METABOLIC PROCESS", "NEGATIVE REGULATION OF BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF CELLULAR BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF CELLULAR MACROMOLECULE BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF MACROMOLECULE METABOLIC PROCESS", "RESPONSE TO EXTERNAL STIMULUS", "RESPONSE TO EXTRACELLULAR STIMULUS", "CELLULAR HOMEOSTASIS", "HOMEOSTATIC PROCESS", "REGULATION OF HOMEOSTATIC PROCESS", "ORGANIC SUBSTANCE TRANSPORT", "CELLULAR NITROGEN COMPOUND CATABOLIC PROCESS", "ORGANIC ACID BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF ORGANELLE ORGANIZATION", "ORGANELLE FISSION", "NEGATIVE REGULATION OF CELLULAR COMPONENT ORGANIZATION", "NEGATIVE REGULATION OF NITROGEN COMPOUND METABOLIC PROCESS", "CELLULAR DEVELOPMENTAL PROCESS", "MAINTENANCE OF LOCATION IN CELL","REGULATION OF DEVELOPMENTAL PROCESS","SMALL MOLECULE CATABOLIC PROCESS","ORGANIC ACID TRANSPORT","CARBOXYLIC ACID TRANSPORT", "CELLULAR RESPONSE TO EXTERNAL STIMULUS","NEGATIVE REGULATION OF RESPONSE TO STIMULUS","RESPONSE TO ENDOGENOUS STIMULUS","CELLULAR RESPONSE TO ENDOGENOUS STIMULUS","REGULATION OF LIGASE ACTIVITY", "CELLULAR COMPONENT MACROMOLECULE BIOSYNTHETIC PROCESS","REGULATION OF CELLULAR KETONE METABOLIC PROCESS", "POSITIVE REGULATION OF ORGANELLE ORGANIZATION", "RIBONUCLEOPROTEIN COMPLEX BIOGENESIS", "PROTEIN COMPLEX SUBUNIT ORGANIZATION", "PROTEIN COMPLEX BIOGENESIS", "PROTEIN COMPLEX ASSEMBLY", "CELLULAR PROTEIN COMPLEX ASSEMBLY", "RIBONUCLEOPROTEIN COMPLEX SUBUNIT ORGANIZATION", "RIBONUCLEOPROTEIN COMPLEX ASSEMBLY", "REGULATION OF PROTEIN COMPLEX ASSEMBLY", "PROTEIN COMPLEX DISASSEMBLY", "RIBONUCLEOPROTEIN COMPLEX LOCALIZATION", "RIBONUCLEOPROTEIN COMPLEX EXPORT FROM NUCLEUS", "CELLULAR PROTEIN COMPLEX DISASSEMBLY", "REGULATION OF PROTEIN COMPLEX DISASSEMBLY", "PROTEIN COMPLEX LOCALIZATION", "POSITIVE REGULATION OF PROTEIN COMPLEX ASSEMBLY", "CELLULAR PROTEIN COMPLEX LOCALIZATION", "NEGATIVE REGULATION OF PROTEIN COMPLEX DISASSEMBLY", "NEGATIVE REGULATION OF PROTEIN COMPLEX ASSEMBLY", "SMALL NUCLEOLAR RIBONUCLEOPROTEIN COMPLEX ASSEMBLY", "RIBONUCLEOPROTEIN COMPLEX DISASSEMBLY", "CHAPERONE-MEDIATED PROTEIN COMPLEX ASSEMBLY", "POSITIVE REGULATION OF PROTEIN COMPLEX DISASSEMBLY", "NEGATIVE REGULATION OF MACROMOLECULE BIOSYNTHETIC PROCESS", "CELLULAR COMPONENT MOVEMENT", "CELLULAR COMPONENT DISASSEMBLY", "REGULATION OF CELLULAR COMPONENT SIZE", "CELLULAR COMPONENT MAINTENANCE", "REGULATION OF CELLULAR COMPONENT BIOGENESIS", "CELLULAR COMPONENT DISASSEMBLY AT CELLULAR LEVEL", "CELLULAR COMPONENT MAINTENANCE AT CELLULAR LEVEL", "NEGATIVE REGULATION OF CELLULAR METABOLIC PROCESS", "RESPONSE TO ORGANIC SUBSTANCE", "CELLULAR CHEMICAL HOMEOSTASIS", "CHEMICAL HOMEOSTASIS", "REGULATION OF RESPONSE TO STIMULUS", "POSITIVE REGULATION OF RESPONSE TO STIMULUS"),
                          bp.lenient=c("POSITIVE REGULATION OF MACROMOLECULE METABOLIC PROCESS", "REGULATION OF CELLULAR COMPONENT ORGANIZATION", "POSITIVE REGULATION OF METABOLIC PROCESS", "POSITIVE REGULATION OF CELLULAR METABOLIC PROCESS", "POSITIVE REGULATION OF CELLULAR PROCESS", "REGULATION OF CELLULAR PROCESS", "REGULATION OF CATALYTIC ACTIVITY", "POSITIVE REGULATION OF CATALYTIC ACTIVITY", "REGULATION OF MOLECULAR FUNCTION", "POSITIVE REGULATION OF CELLULAR COMPONENT ORGANIZATION", "REGULATION OF ORGANELLE ORGANIZATION", "POSITIVE REGULATION OF CATABOLIC PROCESS", "POSITIVE REGULATION OF CELLULAR CATABOLIC PROCESS", "POSITIVE REGULATION OF MOLECULAR FUNCTION", "REGULATION OF CATABOLIC PROCESS", "REGULATION OF CELLULAR CATABOLIC PROCESS", "CELLULAR RESPONSE TO CHEMICAL STIMULUS", "CELLULAR RESPONSE TO ORGANIC SUBSTANCE", "POSITIVE REGULATION OF BIOSYNTHETIC PROCESS", "POSITIVE REGULATION OF CELLULAR BIOSYNTHETIC PROCESS", "POSITIVE REGULATION OF MACROMOLECULE BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF CELLULAR BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF CELLULAR MACROMOLECULE BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF MACROMOLECULE METABOLIC PROCESS", "RESPONSE TO EXTERNAL STIMULUS", "RESPONSE TO EXTRACELLULAR STIMULUS", "CELLULAR HOMEOSTASIS", "HOMEOSTATIC PROCESS", "REGULATION OF HOMEOSTATIC PROCESS", "ORGANIC SUBSTANCE TRANSPORT", "ORGANIC ACID BIOSYNTHETIC PROCESS", "NEGATIVE REGULATION OF ORGANELLE ORGANIZATION", "ORGANELLE FISSION", "NEGATIVE REGULATION OF CELLULAR COMPONENT ORGANIZATION", "CELLULAR DEVELOPMENTAL PROCESS", "MAINTENANCE OF LOCATION IN CELL","REGULATION OF DEVELOPMENTAL PROCESS","SMALL MOLECULE CATABOLIC PROCESS","ORGANIC ACID TRANSPORT", "CELLULAR RESPONSE TO EXTERNAL STIMULUS","NEGATIVE REGULATION OF RESPONSE TO STIMULUS","RESPONSE TO ENDOGENOUS STIMULUS","CELLULAR RESPONSE TO ENDOGENOUS STIMULUS","REGULATION OF LIGASE ACTIVITY", "CELLULAR COMPONENT MACROMOLECULE BIOSYNTHETIC PROCESS", "POSITIVE REGULATION OF ORGANELLE ORGANIZATION", "NEGATIVE REGULATION OF MACROMOLECULE BIOSYNTHETIC PROCESS", "CELLULAR COMPONENT MOVEMENT", "CELLULAR COMPONENT DISASSEMBLY", "REGULATION OF CELLULAR COMPONENT SIZE", "CELLULAR COMPONENT MAINTENANCE", "REGULATION OF CELLULAR COMPONENT BIOGENESIS", "CELLULAR COMPONENT DISASSEMBLY AT CELLULAR LEVEL", "CELLULAR COMPONENT MAINTENANCE AT CELLULAR LEVEL", "NEGATIVE REGULATION OF CELLULAR METABOLIC PROCESS", "RESPONSE TO ORGANIC SUBSTANCE", "CELLULAR CHEMICAL HOMEOSTASIS", "CHEMICAL HOMEOSTASIS", "REGULATION OF RESPONSE TO STIMULUS", "POSITIVE REGULATION OF RESPONSE TO STIMULUS"),
                          complexes=c("GOLGI APPARATUS","CELL CORTEX","CELL WALL","CELLULAR BUD","CHROMOSOME","CYTOPLASM","CYTOPLASMIC MEMBRANE-BOUNDED VESICLE","CYTOSKELETON","ENDOMEMBRANE SYSTEM","ENDOPLASMIC RETICULUM","MEMBRANE FRACTION","MEMBRANE","MICROTUBULE ORGANIZING CENTER","MITOCHONDRIAL ENVELOPE","MITOCHONDRION","HETEROGENEOUS NUCLEAR RIBONUCLEOPROTEIN COMPLEX","NUCLEOLUS","NUCLEUS","PEROXISOME","PLASMA MEMBRANE","SITE OF POLARIZED GROWTH","VACUOLE","POLAR MICROTUBULE","SMALL NUCLEAR RIBONUCLEOPROTEIN COMPLEX","SMALL NUCLEOLAR RIBONUCLEOPROTEIN COMPLEX","TRANSCRIPTION FACTOR COMPLEX","CDC73-PAF1 COMPLEX","SIGNAL RECOGNITION PARTICLE", "ARP2-3 PROTEIN COMPLEX", "CCR4-NOT NOT2-NOT5 SUBCOMPLEX", "CDC48-UFD1-NPL4 COMPLEX", "EKC-KEOPS PROTEIN COMPLEX", "HDA COMPLEX", "HRD1 UBIQUITIN LIGASE ERAD-L COMPLEX", "MRNA CAPPING ENZYME COMPLEX", "NRD1-NAB3-SEN1 TERMINATION COMPLEX", "RIC1-RGP1 COMPLEX", "SNRNP U2", "SNRNP U6", "RNA POLYMERASE III COMPLEX"))

library(dplyr)
library(igraph)
library(visNetwork)
library(gplots)
#########
# reads gene sets/signatures, from a given file in gmt format
# sigFileName - the name of the gmt file
# RETURNS a list of gene sets, where each list element is a vector of genes
#         - the names of the list elements are the GO term names
#########
myreadSigs = function (sigFileName) 
{
  sigs <- scan(sigFileName, what = character(), sep = "\n")
  sigs <- strsplit(sigs, split = "\t")
  names(sigs) <- sapply(sigs, function(vec) {
    vec[1]
  })
  sigs <- lapply(sigs, function(vec) {
    setdiff(vec[-c(1:2)], "NULL")
  })
  lens <- sapply(sigs, length)
  sigs[lens > 0]
}


########
#bp_file = myreadSigs("BP_geneNames_current.gmt")
########
# fdrThresh - FDR threshold; only show gene sets that pass this significance threshold
# goTable - a dataframe with the following columns describing GO terms:
#         - "term" (GO term), "id" (GOID)
#         - if provided (i.e. not NULL), the GO ID numbers of the enriched GO terms will be saved in
#           the output xgmml file as a node attribute called "GOID".
#         - the GOID allows for an easy link to the GO website page for the associated GO term
#         
# compute the leading edge (basic computations)
# geneSet - gene set (as a vector) for which the leading edge will be computed
# scoreMat - data.frame of gene scores; must contain "ID" (for gene IDs) and "score" columns
# p - weight
# isSorted - TRUE/FALSE indicating whether or not the genes in scoreMat have been
#            sorted by score in decreasing order
# keepIndex - TRUE/FALSE indicating whether or not to return the indices of the leading edge gene in 
#         the list of all genes sorted by score in decreasing order
# verbose - TRUE/FALSE indicating whether or not to print messages during the computation
# RETURNS scoreMat restricted to the leading edge genes and an "index" column if keepIndex=TRUE
# 




myrun_go_enrich2 = function (fdrThresh = 0.1, curr_exp, score, bp_path, go_path = NULL){
  
  fdrThresh = as.numeric(fdrThresh)
  
  bp_file = file.path(bp_path)
  scoreMat = score
  queryGenes.mn <- sort(unique(scoreMat$gene[which(scoreMat$index >= 1)]))
  uniGenes.mn <- sort(unique(scoreMat$gene[!is.na(scoreMat$score)]))
  bp <- readRDS(bp_file)
  enrichMat.mn <- myhyperG(querySet = queryGenes.mn, geneSets = bp,
                           uni = uniGenes.mn, scoreMat = score, minSetSize = 5,
                           maxSetSize = 300, uniSize = NA)
  queryGeneSets = list()
  queryGeneSets[[curr_exp]] = queryGenes.mn
  enrichMat.mn$filename <- curr_exp
  enrichMat_Ordered = enrichMat.mn[with(enrichMat.mn, order(FDR,
                                                            -foldEnrichment)), ]
  scoreMat <- scoreMat[order(scoreMat$score, decreasing = T),
                       ]
  scoreMat <- scoreMat[match(uniGenes.mn, scoreMat$gene), "score",
                       drop = F]
  rownames(scoreMat) <- uniGenes.mn
  colnames(scoreMat) <- curr_exp
  
  nonEnrichMat.mn <- mygenesNotInEnrichedTerm(queryGeneSets,
                                              enrichMat.mn, scoreMat, NONSPECIFIC.TERMS$bp, fdrThresh)
  
  bp <- lapply(bp, intersect, uniGenes.mn)
  lens <- sapply(bp, length)
  bp <- bp[lens >= 5 & lens <= 300]
  
  q = myclusterEnrich(enrichInfo = enrichMat.mn, geneSets = bp,
                      outFile = curr_exp, fdrThresh = fdrThresh, overlapThresh = 0.5,
                      nonEnrichInfo = nonEnrichMat.mn, barModGenes = NULL,
                      scoreName = "score", plotForEachEnrichedTerm = T, go_path = go_path)
                        
  return(list(enrichInfo = q$enrichInfo , edgeMat = q$edgeMat))
}


#######
# generates an enrichment map in xgmml format using hypergeometric test statistics
# enrichInfo - dataframe with enrichment stats for gene sets (one per row), with the following columns:
#              term, geneSetFraction, querySetFraction, FDR, overlapGenes, maxOverlapGeneScore
#            - see documentation for the output of hyperG() for descriptions of these columns
# geneSets - named list of gene sets tested for significant overlap w/ the query set, 
#              restricted to genes in the universe
# outFile - the output xgmml file will be saved to this location
# fdrThresh - FDR threshold; only show gene sets that pass this significance threshold
# overlapThresh - an edge between a pair of enriched gene sets will only be shown if the overlap coefficient
#              is >= overlapThresh
# nonEnrichInfo - dataframe with info on gene sets that are *not* significantly enriched (one per row)
#             with the following columns:
#             term, overlapGenes, maxOverlapGeneScore, geneSetFraction, unenrichedGenes
#            - see documentation for the output of genesNotInEnrichedTerm() for descriptions of these columns
#            - can be NULL
# barModGenes - if provided (i.e. not NULL) a vector of genes that should be marked distinctly in the 
#              barplots, should they be in the top overlap genes
# scoreName - score label to use in top overlap gene barplots
# plotForEachEnrichedTerm - if TRUE, a top overlap gene barplot will be created for each enriched term;
#              if FALSE, a barplot will be created for each enriched term cluster
# goTable - a dataframe with the following columns describing GO terms:
#         - "term" (GO term), "id" (GOID)
#         - if provided (i.e. not NULL), the GO ID numbers of the enriched GO terms will be saved in
#           the output xgmml file as a node attribute called "GOID".
#         - the GOID allows for an easy link to the GO website page for the associated GO term

#####
myclusterEnrich = function (enrichInfo, geneSets, outFile, fdrThresh = 0.1, overlapThresh = 0.5,
                            nonEnrichInfo = NULL, barModGenes = NULL, scoreName = "Fitness defect score",
                            plotForEachEnrichedTerm = F, go_path = NULL){
  
  
  go_file = file.path(go_path)
  if(!is.null(go_path)) goTable = read.delim(go_file,stringsAsFactors = F,check.names = F)
  nodeSizeRange <- c(10, 40)
  prunedCol <- "#BEBEBE"
  labelWidth <- 20
  edgeWidthRange <- c(1, 5)
  overlapCoeffRange <- c(overlapThresh, 1)
 
  if (!is.null(nonEnrichInfo)) {
    nonEnrichInfo$maxOverlapGeneScore <- round(nonEnrichInfo$maxOverlapGeneScore,
                                               2)
    nonEnrichInfo$geneSetFraction <- round(nonEnrichInfo$geneSetFraction *
                                             100, 1)
    if (is.null(nonEnrichInfo$nGenes)) {
      lens <- sapply(geneSets, length)
      i <- match(nonEnrichInfo$term, names(lens))
      nonEnrichInfo$nGenes <- lens[i]
    }
    tmp <- strsplit(nonEnrichInfo$overlapGenes, "\\|")
    w <- which(is.na(tmp))
    if(length(w)>0) tmp = tmp[-w]
    if (is.null(nonEnrichInfo$unenrichedGenes)) {
      nonEnrichInfo$overlapGenes <- sapply(tmp, paste,
                                           collapse = "| ")
    }
    else {
      unEnriched <- strsplit(nonEnrichInfo$unenrichedGenes,
                             "\\|")
      tmp.mod <- sapply(1:length(tmp), function(termI) {
        vec <- tmp[[termI]]
        i <- match(unEnriched[[termI]], tmp[[termI]])
        vec[i] <- paste("<b>", vec[i], "</b>", sep = "")
        paste(vec, collapse = "| ")
      })
      
      nonEnrichInfo$overlapGenes <- tmp.mod
    }
    
    if (is.null(enrichInfo)) {
      
      return()
    }
  }
  ###### key step to exit
  enrichInfo <- enrichInfo[enrichInfo$FDR <= fdrThresh, , drop = F]
  #print(enrichInfo[1:5,1:5])
  #print(dim(enrichInfo))
  enrich = enrichInfo
  
  if(!is.null(go_path)) {
    toDoI <- match(enrichInfo$term, goTable$term)
    enrichInfo$GOID = goTable$GOID[toDoI]
  }
  
  if (nrow(enrichInfo) == 0) {
    print("No enriched terms to cluster.")
    return()
  }
  enrichInfo$formattedLabel <- sapply(enrichInfo$term, function(curLabel) {
    curLabel <- strwrap(curLabel, labelWidth)
    paste(curLabel, collapse = "\n")
  })
  i <- match(enrichInfo$term, names(geneSets))
  if (any(is.na(i))) {
    stop("Could not find gene sets for ", sum(is.na(i)),
         " enriched terms.")
  }
  geneSets <- geneSets[i]
  if (is.null(enrichInfo$nGenes)) {
    enrichInfo$nGenes <- sapply(geneSets, length)
  }
  tmpSize <- -log10(enrichInfo$FDR)
  maxVal <- max(tmpSize[!is.infinite(tmpSize)])
  tmpSize[is.infinite(tmpSize)] <- maxVal + 2
  gsSizeRange <- range(tmpSize)
  if (gsSizeRange[1] == gsSizeRange[2]) {
    gsSizeRange[1] <- -log10(fdrThresh)
    gsSizeRange[2] <- gsSizeRange[2] + 1
  }
  tmpSize <- (tmpSize - gsSizeRange[1])/(gsSizeRange[2] - gsSizeRange[1])
  tmpSize <- nodeSizeRange[1] + tmpSize * (nodeSizeRange[2] -nodeSizeRange[1])
  enrichInfo$size <- round(tmpSize, 2)
  if (nrow(enrichInfo) == 1) {
    enrichInfo$cluster <- CLUST.COL[1]
    edgeMat <- NULL
  }
  else {
    pairI <- getUniquePairs(length(geneSets))
    distVal <- apply(pairI, 1, function(onePair) {
      myoverlapCoeff(geneSets[onePair])
    })
    distVal[distVal < overlapThresh] <- 0
    edgeMat <- data.frame(nodeA = pairI[, 1], nodeB = pairI[,
                                                            2], coeff = distVal)
    enrichInfo$cluster <- prunedCol
    if (is.null(enrichInfo$pruneOutcome)) {
      termI <- 1:nrow(enrichInfo)
    }
    else {
      termI <- which(enrichInfo$pruneOutcome == enrichInfo$term)
    }
    if (length(termI) == 1) {
      enrichInfo$cluster[termI] <- CLUST.COL[1]
    }
    else {
      i <- which((edgeMat$nodeA %in% termI) & (edgeMat$nodeB %in%
                                                 termI))
      enrichInfo$id = termI
      g=igraph::graph_from_data_frame(edgeMat[which(edgeMat$coeff!=0),],directed = F,vertices = enrichInfo$id)
      adj = igraph::as_adjacency_matrix(g)
      clusters = igraph::clusters(g)
      clusters = split(names(clusters$membership),clusters$membership)
      #clusters <- mclWrapper(edgeMat[i, , drop = F], dirname(outFile))
      mcl.in = edgeMat[i, , drop = F]
      if(is.null(mcl.in)) print("edge NULL")
      mcl.out = clusters
      clusters <- lapply(clusters, as.numeric)
      # if (length(clusters) > length(CLUST.COL)) {
      #   stop("Need more cluster colours!")
      # }
      lens <- sapply(clusters, length)
      clusters <- data.frame(id = unlist(clusters), cluster = CLUST.COL[rep(1:length(clusters),
                                                                            lens)], stringsAsFactors = F)
      enrichInfo$cluster[clusters$id] <- clusters$cluster
    }
    edgeMat <- edgeMat[edgeMat$coeff > 0, , drop = F]
    if (nrow(edgeMat) > 0) {
      edgeMat$size <- (edgeMat$coeff - overlapCoeffRange[1])/(overlapCoeffRange[2] -
                                                                overlapCoeffRange[1])
      edgeMat$size <- edgeWidthRange[1] + edgeMat$size *
        (edgeWidthRange[2] - edgeWidthRange[1])
      edgeMat$coeff <- round(edgeMat$coeff, 2)
      edgeMat$size <- round(edgeMat$size, 2)
    }
    else {
      edgeMat <- NULL
    }
  }
  otherI <- order(enrichInfo$cluster)
  otherI <- otherI[order(enrichInfo$FDR[otherI])]
  termI <- which(enrichInfo$cluster[otherI] != prunedCol)
  if (length(termI) < length(otherI)) {
    otherI <- c(otherI[termI], otherI[-termI])
  }
  enrichInfo$id <- 1:nrow(enrichInfo)
  enrichInfo <- enrichInfo[otherI, , drop = F]
  enrichInfo$geneSetFraction <- round(enrichInfo$geneSetFraction *
                                        100, 1)
  
  
  ### here come the edge matrrix
  if (is.null(edgeMat)) print("edgeMat is NULL")
  #below doesn't work...
  #if(is.null(edgeMat))  {stop("No fucking Go enrichment")}
  
  if (!is.null(edgeMat)) {
    nam = c("source","target","label","overlapCoeff","width")
    orig = c("nodeA","nodeB","label","coeff","size")
    m = match(edgeMat$nodeA,as.numeric(as.factor(names(geneSets))))
    src = names(geneSets)[m]
    m = match(edgeMat$nodeB,as.numeric(as.factor(names(geneSets))))
    trg = names(geneSets)[m]
    edgeMat$label = paste(src,"(overlap)",trg)
    m = match(names(edgeMat),orig)
    names(edgeMat) = nam[m]
  }
  
 
  output = list(enrichInfo = enrichInfo,edgeMat = edgeMat)
  
  return(output)
}

####
#this is equivalent to t(combn(maxVal,2))
##### required functions
# computes the number of unique pairs given the number of items to consider
# maxVal - the maximum number of items
# RETURNS a 2-column matrix where each row contains a different pair, specified with item indices
getUniquePairs = function (maxVal)
{
  firstI <- rep(1:(maxVal - 1), (maxVal - 1):1)
  secondI <- sapply(2:maxVal, function(x) {
    x:maxVal
  })
  cbind(firstI, unlist(secondI))
}

# t_col <- function(color, percent = 50, name = NULL) {
#   #      color = color name
#   #    percent = % transparency
#   #       name = an optional name for the color
#   ## Get RGB values for named color
#   rgb.val <- col2rgb(color)
#   
#   ## Make new color using input color as base and alpha set by transparency
#   t.col <- rgb(rgb.val[1], rgb.val[2], rgb.val[3],
#     max = 255,
#     alpha = (100 - percent) * 255 / 100,
#     names = name)
#   
#   ## Save the color
#   invisible(t.col)
# }
# 
# lighten <- function(color, factor=1.4){
# col <- col2rgb(color)
# col <- col*factor
# col <- rgb(t(as.matrix(apply(col, 1, function(x) if (x > 255) 255 else x))), maxColorValue=255)
# col
# }

# lighten <- function(color, factor=1.4){
#   col <- col2rgb(color)
#   col <- col*factor
#   col <- rgb(t(col), maxColorValue=255)
#   col
# }

mycolors = c(
  "darkorange1",
  "dodgerblue",
  "darkgreen",
  "navy",
  "mediumpurple"  ,
  "royalblue3",
  "darkolivegreen4",
  "firebrick",
  "cyan4",
  "hotpink3",
  "plum4",
  "blue",
  "magenta4",
  "skyblue3",
  "green4",
  "red3",
  "steelblue3",
  "tomato",
  "purple4",
  "goldenrod3",
  "steelblue",
  "darkred",
  "lightpink3",
  "darkorchid",
  "lightblue3",
  "dimgrey",
  "chocolate1",
  "seagreen3",
  "darkkhaki",
  "darksalmon"
)
CLUST.COL <- c("#FF00CC","#33CCFF", "#33CC00", "#9900FF", "#FF9900", "#FFFF00", "#FFCCFF", "#FF0000", "#006600", "#009999", "#CCCC00", "#993300", "#CC99CC", "#6699CC","#CCCCFF", "#FFCC99", "#9966FF", "#CC6600", "#CCFFFF", "#99CC00", "#FF99FF", "#0066FF", "#66FFCC", "#99CCFF", "#9999CC", "#CC9900", "#CC33FF", "#006699", "#F5DF16", "#B5185E", "#99FF00", "#00FFFF", "#990000", "#CC0000", "#33CCCC", "#CC6666", "#996600", "#9999FF", "#3366FF")
rc=col2hex(mycolors)

CLUST.COL = c(CLUST.COL,rc) 
#####hiphop:::hyperG
# computes enrichment using the hypergeometric test, and uses the resulting P values with
# the Benjamini Hochberg method to estimate FDR values
# querySet - character vector of genes in query set
# geneSets - named list of gene sets to test for significant overlap w/ the query set
# scoreMat - dataframe of gene scores
#          - first column = scores, gene column
#          - can be NULL
# uni - character vector of genes in the universe (i.e. background set)
#     - if NULL, must specify uniSize
# uniSize - the # of genes in the universe
# minSetSize, maxSetSize - min/max # of genes in geneSets (after restricting to the gene universe)
# RETURNS a dataframe of enrichment results, sorted by increasing FDR value. The columns are:
#         term = name of gene set
#         querySetFraction = the fraction of the query set that overlaps with the term set
#         geneSetFraction = the fraction of the term set that overlaps with the query set
#         foldEnrichment = the fold enrichment of the query set with the term genes
#         P = P value estimating the significance with which the query set is enriched with the term genes
#         FDR = FDR value estimating the significance of enrichment
#         overlapGenes = a |-separated list of genes in the overlap of the query set and the term set;
#                        if scoreMat is provided (not NULL), the scores of the genes are shown in parentheses
#	  maxOverlapGeneScore = if scoreMat is provided (not NULL), the maximum score of the overlapGenes
myhyperG = function (querySet, geneSets, uni, scoreMat, minSetSize = 5, 
  maxSetSize = 300, uniSize = NA) 
{
  if (!is.null(uni)) {
    geneSets <- lapply(geneSets, intersect, uni)
    lens <- sapply(geneSets, length)
    geneSets <- geneSets[lens >= minSetSize & lens <= maxSetSize]
    uniSize <- length(uni)
  }
  if (!is.null(scoreMat)) {
    scoreMat <- scoreMat[order(scoreMat$score, decreasing = T), 
      ]
    if (!is.null(uni)) {
      i <- match(uni, scoreMat$gene)
      scoreMat <- scoreMat[sort(i[!is.na(i)]), ]
    }
    scoreMat$score <- round(scoreMat$score, 2)
  }
  enrichInfo <- sapply(geneSets, function(geneSet) {
    overlapSet <- intersect(querySet, geneSet)
    pVal <- phyper(length(overlapSet) - 1, length(geneSet), 
      uniSize - length(geneSet), length(querySet), lower.tail = F)
    if (length(overlapSet) > 0) {
      overlapSet <- sort(overlapSet)
    }
    overlapSize <- length(overlapSet)
    if (is.null(scoreMat)) {
      maxScore <- NA
    }
    else {
      i <- sort(match(overlapSet, scoreMat$gene))
      maxScore <- scoreMat$score[i[1]]
      overlapSet <- paste(scoreMat$gene[i], "(", scoreMat$score[i], 
        ")", sep = "")
    }
    overlapSet <- paste(overlapSet, collapse = "|")
    bgRate <- length(geneSet)/uniSize
    foldEnrich <- overlapSize/length(querySet)/bgRate
    c(overlapSet, overlapSize/length(geneSet), foldEnrich, 
      pVal, maxScore, overlapSize/length(querySet))
  })
  enrichInfo <- t(enrichInfo)
  enrichCol <- data.frame(term = names(geneSets), querySetFraction = as.numeric(enrichInfo[, 
    6]), geneSetFraction = as.numeric(enrichInfo[, 2]), foldEnrichment = as.numeric(enrichInfo[, 
      3]), P = as.numeric(enrichInfo[, 4]), FDR = p.adjust(as.numeric(enrichInfo[, 
        4]), method = "BH"), overlapGenes = enrichInfo[, 1], 
    maxOverlapGeneScore = as.numeric(enrichInfo[, 5]), stringsAsFactors = F)
  rownames(enrichCol) <- NULL
  enrichCol = enrichCol[order(enrichCol$FDR), ]
}
#######hiphop:::overlapCoeff
#######the overlap of genesets for all combinations
#######If set X is a subset of Y or the converse then the overlap coefficient is equal to 1.

# compute the overlap coefficient given a pair of (gene) sets 
# gsPairList - a list of two sets (each set is a vector of IDs)
# RETURNS the overlap coefficient

myoverlapCoeff = function (gsPairList) 
{
  length(intersect(gsPairList[[1]], gsPairList[[2]]))/min(length(gsPairList[[1]]), 
    length(gsPairList[[2]]))
}
# generates a dataframe of gene sets that are *not* significantly enriched, yet they contain query genes,
# i.e. genes in chemical-genetic interactions
# queryGeneSets - named list of queryGeneSets, where each list element is a vector of query genes
#           - the names are filenames (typically) identifying different experiments
# enrichMat - dataframe with enrichment stats for gene sets (one per row), with the following columns:
#             filename, term, geneSetFraction, FDR, overlapGenes, maxOverlapGeneScore
#           - see documentation for the output of hyperG() for descriptions of these columns
#           - rows with the same value, x, in the filename column specify enrichment results for
#             the set of query genes in queryGeneSets with name=x
# scoreMat - score matrix/dataframe; row names are gene IDs and column names are filenames
#          - each column contains a different set of scores
# termsToExclude - vector of terms (i.e. names of gene sets) to exclude from the results; can be NULL
# fdrThresh - FDR threshold; only show gene sets that do not pass this significance threshold
# RETURNS a dataframe of gene sets that are not significantly enriched (one per row),
#         sorted by decreasing maxOverlapGeneScore value. The dataframe includes these columns:
#         filename = filename identifying the query gene set
#         term = gene set name
#         geneSetFraction = the fraction of the term set that overlaps with the query set
#         overlapGenes = a |-separated list of genes in the overlap of the query set and the term set;
#             the scores of the genes are shown in parentheses
#	  maxOverlapGeneScore = the maximum score of the overlapGenes
#         unenrichedGenes = a |-separated list of genes in the overlap of the query set and the term set
#             that *also* do not belong to any significantly enriched term set;
# 
mygenesNotInEnrichedTerm = function (queryGeneSets, enrichMat, scoreMat, termsToExclude , 
  fdrThresh = 0.1) 
{
  scoreMat <- as.matrix(scoreMat)
  enrichMat <- enrichMat[!(enrichMat$term %in% termsToExclude), 
    , drop = F]
  lens <- sapply(queryGeneSets, length)
  queryGeneSets <- queryGeneSets[lens > 0]
  oGenes <- strsplit(enrichMat$overlapGenes, "\\|")
  oGenes <- lapply(oGenes, function(genes) {
    genes <- strsplit(genes, "\\(")
    sapply(genes, function(vec) {
      vec[1]
    })
  })
  rowI <- split(1:nrow(enrichMat), enrichMat$filename)
  enrichI <- match(names(queryGeneSets), names(rowI))
  extraGenes <- queryGeneSets[is.na(enrichI)]
  queryGeneSets <- queryGeneSets[!is.na(enrichI)]
  rowI <- rowI[enrichI[!is.na(enrichI)]]
  tmp <- lapply(1:length(queryGeneSets), function(expI) {
    setdiff(queryGeneSets[[expI]], unlist(oGenes[rowI[[expI]]]))
  })
  names(tmp) <- names(queryGeneSets)
  extraGenes <- c(extraGenes, tmp)
  lens <- sapply(extraGenes, length)
  extraGenes <- extraGenes[lens > 0]
  if (length(extraGenes) > 0) {
    lens <- lens[lens > 0]
    extraGenes <- data.frame(filename = rep(names(extraGenes), 
      lens), gene = unlist(extraGenes), stringsAsFactors = F)
    i <- match(extraGenes$gene, rownames(scoreMat))
    i <- cbind(i, match(extraGenes$filename, colnames(scoreMat)))
    extraGenes$score <- round(scoreMat[i], 2)
    extraGenes <- extraGenes[order(extraGenes$score, decreasing = T), 
      ]
    i <- split(1:nrow(extraGenes), extraGenes$filename)
    extraGenes <- lapply(i, function(curRow) {
      tmp <- paste(extraGenes$gene[curRow], "(", extraGenes$score[curRow], 
        ")", sep = "")
      c(extraGenes$score[curRow[1]], paste(tmp, collapse = "|"))
    })
  }
  tmp <- lapply(1:length(queryGeneSets), function(expI) {
    curRow <- rowI[[expI]]
    sigI <- curRow[enrichMat$FDR[curRow] <= fdrThresh]
    unenrichedGenes <- setdiff(queryGeneSets[[expI]], unlist(oGenes[sigI]))
    curRow <- setdiff(curRow, sigI)
    if (length(curRow) == 0) {
      return(list(rowI = NULL, unenrichedGenes = NULL))
    }
    unenrichedGenes <- lapply(oGenes[curRow], function(genes) {
      intersect(unenrichedGenes, genes)
    })
    lens <- sapply(unenrichedGenes, length)
    unenrichedGenes <- unenrichedGenes[lens > 0]
    curRow <- curRow[lens > 0]
    if (length(curRow) == 0) {
      return(list(rowI = NULL, unenrichedGenes = NULL))
    }
    expI <- match(enrichMat$filename[curRow[1]], colnames(scoreMat))
    unenrichedGenes <- lapply(unenrichedGenes, function(curGenes) {
      geneI <- match(curGenes, rownames(scoreMat))
      geneStr <- scoreMat[geneI, expI]
      names(geneStr) <- curGenes
      geneStr <- round(sort(geneStr, decreasing = T), 2)
      geneStr <- paste(names(geneStr), "(", geneStr, ")", 
        sep = "")
      paste(geneStr, collapse = "|")
    })
    list(rowI = curRow, unenrichedGenes = unenrichedGenes)
  })
  unenrichedMat <- enrichMat[unlist(lapply(tmp, function(ob) {
    ob$rowI
  })), ]
  unenrichedMat$unenrichedGenes <- unlist(lapply(tmp, function(ob) {
    ob$unenrichedGenes
  }))
  if (length(extraGenes) > 0) {
    unenrichedMat <- unenrichedMat[c(rep(1, length(extraGenes)), 
      1:nrow(unenrichedMat)), ]
    toDoI <- 1:length(extraGenes)
    unenrichedMat$filename[toDoI] <- names(extraGenes)
    unenrichedMat$term[toDoI] <- "OTHER"
    unenrichedMat$overlapGenes[toDoI] <- sapply(extraGenes, 
      function(vec) {
        vec[2]
      })
    unenrichedMat$maxOverlapGeneScore[toDoI] <- as.numeric(sapply(extraGenes, 
      function(vec) {
        vec[1]
      }))
    unenrichedMat$unenrichedGenes[toDoI] <- unenrichedMat$overlapGenes[toDoI]
    if (!is.null(unenrichedMat$pruneOutcome)) {
      unenrichedMat$pruneOutcome[toDoI] <- "OTHER"
    }
    naCol <- setdiff(colnames(unenrichedMat), c("filename", 
      "term", "overlapGenes", "maxOverlapGeneScore", "unenrichedGenes"))
    colI <- match(naCol, colnames(unenrichedMat))
    unenrichedMat[toDoI, colI] <- NA
  }
  rownames(unenrichedMat) <- NULL
  unenrichedMat <- unenrichedMat[order(unenrichedMat$geneSetFraction, 
    decreasing = T), ]
  unenrichedMat[order(unenrichedMat$maxOverlapGeneScore, decreasing = T), 
    ]
}
############
# generate leading edge barplots for all clusters
# scoreMat - dataframe: ID, score, optional 3rd column indicating which ones to mark (TRUE/FALSE)
# geneSets - a list of all gene sets, where each list element is a vector of gene IDs
# gsInfo - dataframe of gene set info: id=gene set id, cluster=cluster id, es=enrichment score, fdr=FDR value
# scoreName - score label to use in leading edge plots
# plotCol - the colour of the bars, in hexidecimal format without the '#' character
# RETURNS a dataframe of barplot node info, each row corresponds to a different node;
# contains "id", "image" (google chart URL), "w" (plot width), "h" (plot height), "cluster" columns
#genLeadingEdgePlot.all <- function(scoreMat, geneSets, gsInfo, scoreName, plotCol="BEBEBE") {
####

mygenebarplot = function(overlapGenes) {
  s = strsplit(overlapGenes, "\\|")
  s2 = lapply(s, strsplit, "\\(")
  s3 = lapply(s2, sapply, strsplit, "\\)")
  s4 = lapply(s3, "t")
  s5 = lapply(s4, as.data.frame, stringsAsFactors = F)
  s5 = lapply(s5, function(x) {
    names(x) = c("gene", "score")
    x
  })
  s6 = lapply(s5, function(x) {
    x$gene = unlist(x$gene)
    x$score = unlist(x$score)
    x$score = as.numeric(x$score)
    x = x %>% arrange(score)
    x
  })
  nrows = sapply(s6, nrow)
  w = which(nrows > 10)
  if (length(w) > 0) {
    s6[w] = lapply(s6[w], function(x)
      x = x[1:10, ])
  }
  s6
}
# compute the top leading edge genes common to given gene sets
# geneSets - a list of gene sets, where each list element is a vector of gene IDs
# scoreMat - dataframe of gene scores; must have "ID" (gene ID) and "score" columns
# maxGenes - maximum number of top leading edge genes to return
# RETURNS a matrix of the top leading edge genes, where each row corresponds to one gene;
#         rownames are gene IDs
#         1st column = % of the given gene sets for which the gene is in the leading edge
#         2nd column = gene score
# generate a barplot of the common leading edge genes using google charts (can be visualized
# with the html img tag), bar length corresponds to score
# leadInfo - matrix/dataframe of leading edge genes; rownames = gene IDs, column 1 = % of gene sets, column 2 = score
#          - if a 3rd column is provided, it should provide TRUE/FALSE indicating whether or not the gene 
#            should be marked
# plotCol - the colour of the bars; hexidecimal format without the '#' character
# scoreRange - a vector of the range of scores in the profile; 1st value = min,  2nd value = max
# barWidth - bar width in the plot
# scoreLabel - label for the score axis
# RETURNS a vector of plot info: plot width, plot height and the google chart URL for the plot
# aliias genLeadingEdgePlot.gChart <- function(leadInfo, plotCol, scoreRange, barWidth, scoreLabel="Sensitivity") {
mybarheight = function(leadInfo) {
  scoreRange = range(leadInfo$score)
  
  dataRange <- scoreRange[2] - scoreRange[1]
  
  barLens <- round((leadInfo[, 2] - scoreRange[1]) / dataRange *
                     100)
  w <- 150
  barWidth = 15
  h <- barWidth * length(barLens) + 50
  h
}


