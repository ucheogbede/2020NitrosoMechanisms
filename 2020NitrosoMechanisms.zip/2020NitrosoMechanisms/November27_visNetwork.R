library(shiny)
library(dplyr)
library(DT)
library(shinydashboard)
library(visNetwork)
library(igraph)
library(shinyjs)

source(file.path("modules","2020_Nov27_GOenrichment_functions.R"))
source(file.path("modules" ,"nov26functions.R"))



visNetworkModuleUI <- function(id, label = "visNetwork") {
  tags$style(HTML("
  #resetGO {
  background-color: #000066; /* goMenu */
    border: 8px solid #4d88ff;
  color: white;
  padding: 14px 28px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}


#resetGO hover {
background-color: #4d88ff;
  color: white;
border: 8px solid #000066;
}
   "))
  
  
  ns <- NS(id)
  
  
  
  tagList(
    fluidPage(
      #tabItem("goenrich",
      fluidRow(
        
        column(width  = 3,
               
          box(title = "Select compound:",
              selectizeInput(ns('cmpMOD'),
                         'Screen:', choices = NULL, multiple = F        
                            ),
              status = "primary", solidHeader = T, width = "100%", height = 150),
               
              box(title ="Network navigation:",
                   div(style="font-size:14px",
                       
                       tags$ol(
                         tags$li("Select a gene set node to view genes driving enrichment and GO term details"),
                         
                         tags$li("Right click network to download image")),
                       
                       tags$a(href="https://www.ncbi.nlm.nih.gov/pubmed/16199517", "Sybramanian et al. PNAS 2005,"),
                       tags$a(href="https://www.ncbi.nlm.nih.gov/pubmed/24723613", "Lee et al. Science 2014.")),
                   
                   status = "primary", solidHeader = T,width="100%",height = 150)
               
              ),
        
        
        column(width  = 3, 
               
               box(title = "Set FDR threshold:",
                   sliderInput(ns("fdrMOD"),label = "FDR threshold", min = 0, max = 0.5,
                               value = 0.1, step = 0.05), 
                   status = "primary", solidHeader = T,width="100%", height = 150),
               
               box(title = "Press button to reset compound menu:", align = "center",
                   column(width  = 12, align = "center",
                          actionButton(ns("resetGO"),"cmpMenu")),
                   
                   
                   status = "primary", solidHeader = T,width="100%", height = 150)
               
        ),
        
        
        column(width = 3, 
               
               
               box(title = "Set fitness score threshold:",
                   sliderInput(ns("scorethreshMOD"),label = "input score threshold", min = 0, max = 5,
                               value = 1, step = 0.5),
                   status = "primary", solidHeader = T,width="100%", height = 150),
               
               ####
               box(title ="Download GO term enrichment table:",
                   column(width  = 12, align = "center",
                          downloadButton(ns('enrichdownload'), 'enrichments')),
                   status = "primary", solidHeader = T,width="100%", height = 150)
               
               #####
               
               
               
        ),#coln
        
        column(width = 3,
               tabBox(#title = "Legends",
                 #div(style="font-size:14px",
                 title = tagList(shiny::icon("info-circle"), "GO enrichment legend"),
                 tabPanel("GO enrichment network","Gene sets correspond to the Gene ontology (GO) defined 
                           biological processes. The analysis was restricted to genesets containing between
                           5 and 300 genes. The significance of a gene set enrichment was estimated
                           using the hypergeometric test for the set of genes passing the fitness score threshold. For a given query set, the map shows only the
                           genesets that passed the significance FDR threshold (default = 0.1). In some cases, a similar set 
                           of query set genes drives the enrichment of multiple GO gene sets. Of these GO sets, 
                           we highlight the most significantly enriched, and the rest are considered redundant."),
                 tabPanel("Leading edge genes","The enrichment of a GO gene set is driven by the subset 
                       that is also in the query set derived from the genes passing the fitness score threshold. The barplot in the top contributing genes for a node plotted below
                       summarizes the subset driving the enrichment. Only the top 10 genes are shown."),
                 
                 #status = "primary", solidHeader = T,
                 width = NULL,height = 320)
        )#coln
      ),#fluid row
      
      fluidRow(
        
        box(title =  "GO enrichment network: select a GO term set node to view details.",
            
            visNetworkOutput(ns("network_proxy"),width = "100%",height = 1100),
            width = 9, status = "primary", solidHeader = TRUE),
        
        box(title = "GO term set enrichment details:",width = 3,
            uiOutput(ns("goTable")),solidHeader = T,status = "primary",background = "navy"),
        
        
        box(title = "Top-contributing genes:",width = 3,
            uiOutput(ns("leadingEdge")),solidHeader = T,status = "primary")
      ),
      
      fluidRow(
        box(title = "GoSet Enrichment Table:", DT::dataTableOutput(ns("enrtable")),
            status = "primary", solidHeader = TRUE,width = 9)
      )
      
    ))
  
  
}

visNetworkModule = function(input,output,session, xinput,cmp,tabs, message = "No GO enrichment, try relaxing the FDR or scorethreshold"){
  
  cmpRECVD = reactive({cmp()})
  datRECVD = reactive({xinput()})
  tabRECVD = reactive({tabs()})
  ############################ 
  goenrich <- reactive({ 
    x = xinput()
    
    w = which(colnames(x) %in% input$cmpMOD)
    
    validate(
      need(length(w) != 0, "Please select a compound")
              )
    
    thresh = input$scorethreshMOD
    
    w2 = which(x[,w] >= thresh)
    
    validate(need(length(w2)!=0, message = "No scores above threshold"))

    req(length(w2)!=0)
    
    df = myscore(mat = x,column = colnames(x)[w],sig = thresh)
   
    curr_exp = "network"
    
    FDR = input$fdrMOD
    
    network = myrun_go_enrich2(fdrThresh = FDR, curr_exp = "tst",score = df, bp_path = "2020_Nov27_BP_SGD.RDS",go_path = "2020_Nov27_GOID_terms_df_bp.txt")
    
    validate(
      need(!is.null(network$enrichInfo), message = message)
    )
   
    enrichInfo = network$enrichInfo
    
    req(!(is.null(enrichInfo)))
    
    edgeMat = network$edgeMat
    
    return(network)
  })
    
net <- reactive({ 
  
    req(goenrich()$enrichInfo)
    
    enrich = goenrich()$enrichInfo
    
    edge = goenrich()$edgeMat
    
    vis = visSetup(enrichInfo = enrich,edgeMat = edge)
    
    
    vis
    
    })
############################ 
  output$network_proxy <- renderVisNetwork({
    req(net()$nodes)
    vis = net()
    ns <- session$ns 
    n = net()$nodes
    req(n)
    
    w =  nrow(n)
    n <- n %>% arrange(term)
    
    names = n$id
    
    
    if(nrow(vis$edges)==0) {
      visNetwork(vis$nodes) %>% 
        visNodes(shadow=list(enabled=T,size=25),borderWidth=1) %>%
        visOptions(
          
          highlightNearest = list(enabled = T, degree = 5, hover = T),
          
          
          nodesIdSelection = list(enabled = TRUE, values = names,
                                  style = 'width: 150px;color: #000066;'),
          
          selectedBy = list(variable="FDR",
                            style = 'width: 150px;color: #000066;')) %>%
        
        visEvents(select = "function(nodes) {
                Shiny.onInputChange('current_node_id', nodes.nodes);
                ;}")
    }
    
    
    else {visNetwork(vis$nodes, vis$edges, width = "100%",height = 1100) %>% 
        visNodes(shadow=list(enabled=T,size=25)) %>%
        
        visOptions(
          
          highlightNearest = list(enabled = T, degree = 5, hover = T),
          
          
          nodesIdSelection = list(enabled = TRUE, values = names,
                                  style = 'width: 250px;color: #000066;'),
          
          selectedBy = list(variable="FDR",
                            style = 'width: 250px;color: #000066;')) %>%
        
        visIgraphLayout(type = "full",randomSeed = 999) %>%
        
        visEvents(select = "function(nodes) {
                Shiny.onInputChange('current_node_id', nodes.nodes);
                ;}")
    }
  })
############################  
  output$goTable = renderUI({
    
    req(input$network_proxy_selected)
    
    ns <- session$ns 
    
    DT::dataTableOutput(ns("table1"))
    
  })
############################ 
  output$leadingEdge = renderUI({
    req(input$network_proxy_selected)
    ns <- session$ns 
    plotOutput(ns("bar"), height = hgt())
  })
############################ 
  output$table1 <- DT::renderDataTable({
    
    req(input$network_proxy_selected)
    
    vis = net()
    
    n = net()$nodes
    
    w = which(vis$nodes$id %in% c(input$network_proxy_selected))
    
    
    req(length(w) > 0)
    
    term = vis$nodes$label[w]
    
    nam = c("term","nGenes","geneSetFraction","FDR")
    
    m = match(nam,names(vis$nodes))
    
    n = vis$nodes[w,m]
    
    term = vis$nodes$label[w]
    
    nam = c("term","nGenes","geneSetFraction","FDR")
    
    m = match(nam,names(vis$nodes))
    
    names(vis$nodes)[m] = c("GO term","geneSet size","% of geneSet","FDR")
    
    n = vis$nodes[w,m]
    
    req(nrow(n)!=0)
    
    t = t(n[,2:4])
    
    datatable(t,width=220,caption = htmltools::tags$caption(term,
                                                            style = "caption-side: top; text-align: center; color:black;background:white;font-weight:bold;"),
              options=list(paging=F,scrollY=F,dom="t",scroller=F,searching=F,ordering=F,rowCallback = JS(
                "function(row, data) {",
                "for (i = 1; i < data.length; i++) {",
                "if (data[i]>1000 | data[i]<1){",
                "$('td:eq('+i+')', row).html(data[i].toExponential(1));",
                "}",
                "}",
                "}")),
              height = 400,colnames = "") %>%
      formatStyle( target = "row", color = "black",backgroundColor = "white",
                   columns = c(1,2),fontWeight = "bold")
  })  
############################  
  output$bar <- renderPlot({
    
    req(input$network_proxy_selected)
    
    vis = net()
    
    n = net()$nodes
    
    w = which(vis$nodes$id %in% c(input$network_proxy_selected))
    
    req(length(w) > 0)
    
    n = vis$nodes[w,]
    
    req(nrow(n)!=0)
    
    s6 = mygenebarplot(n$overlapGenes)
    
    barplot(s6[[1]]$score,names.arg = s6[[1]]$gene,las=1,horiz=T,col="dodgerblue")
    
  })
############################ 
  hgt = reactive({
    
    req(input$network_proxy_selected)
    
    vis = net()
    
    n = net()$nodes
    
    w = which(vis$nodes$id %in% c(input$network_proxy_selected))
    
    req(length(w) > 0)
    
    n = vis$nodes[w,]
    
    validate(need(nrow(n)!=0, message = "click node for detail"))
    
    o = mygenebarplot(n$overlapGenes)
    
    height = mybarheight(o[[1]])
    
    height = height*2
    
    
    height
  })
############################ 
  
############################ 
  observeEvent(input$network_proxy_selectedBy,
              
               
               {
                 req(input$network_proxy_selectedBy)
                 
                 n = net()$nodes
                 
                 w = which(n$FDR %in% as.numeric(input$network_proxy_selectedBy))
                 
                 id = n$id[w]
                 
                 ns <- session$ns 
                 visNetworkProxy(ns("network_proxy")) %>%
                   visSelectNodes(id = id)
                 
               }
  )
 ############################ GO ENCHICHMENT TABLE 
  enrid = reactive({
    
    req(net()$nodes)
    
    enrich = net()$nodes
    
    req(length(nrow(enrich)) > 0)
    
    row <- input$enrtable_rows_selected
    
    out = outenrich()
    
    id = out$id[row]
    
    id
    
    
  })
  
  
  
  
############################  
outenrich = reactive({
    
    req(input$cmpMOD)
    req(goenrich()$enrichInfo)
    
    enrich = goenrich()$enrichInfo
    
  #########
  #########
  
   
    
    w = which(names(enrich) %in% c("querySetFraction", "geneSetFraction" ,
                                   "foldEnrichment" , "P" , "FDR" ))
    enrich[,c("querySetFraction","geneSetFraction", "foldEnrichment")] = 
      format(round(enrich[,c("querySetFraction","geneSetFraction", "foldEnrichment")],2),nsmall = 1,scientific = F)
    
    enrich[,c("P", "FDR")] = 
      format(signif(enrich[,c("P", "FDR")],2),nsmall = 1,scientific = T)
    
    enrich
  }
  )  
 ############################  
  observeEvent(enrid(), {
    req(enrid())
    id = enrid()
    
    ns <- session$ns
    visNetworkProxy(ns("network_proxy")) %>%
      visSelectNodes(id = id)
  })
############################   

  
############################ 
output$enrtable = DT::renderDataTable({
    
    out = outenrich()
    w = which(names(out) %in% c("GOID","term","querySetFraction", "geneSetFraction" ,
                                "foldEnrichment" , "P" , "FDR","overlapGenes" ))
    
    out = out[,c("GOID","term","querySetFraction", "geneSetFraction" ,
                 "foldEnrichment" , "FDR","overlapGenes" )]
    
  },escape = F,rownames = F, options = list(
    autoWidth = T,scrollX = T,columnDefs = list(list(width = c('60px'), 
    targets = c(-2)),list(width = c('150px'), targets = c(-6)))),
    selection = "single",server = F)
############################ 

############################ 
output$enrichdownload <- downloadHandler(
    filename = function() {
      paste0("enrich:",input$cmpMOD,"_", Sys.Date(), ".txt")
    },
    content = function(file) {
      write.table(outenrich(), file, row.names = F,sep="\t")
    }
  )
############################ 
  
############################ 
observeEvent(input$resetGO,{
  
    choices = colnames(datRECVD())
    updateSelectizeInput(session,'cmpMOD',label = "",
                         choices = choices, selected = choices[17])
    
    updateSliderInput(session,'scorethreshMOD',label = "input score threshold", min = 0, max = 5,
                      value = 1, step = 0.5)
    updateSliderInput(session,'fdrMOD',label = "FDR threshold", min = 0, max = 0.5,
                      value = 0.1, step = 0.05)
    
  },ignoreInit = F, ignoreNULL = T)

############################ IMPORTANTANT TASK
### updates the MODULE compound if its different from the SERVER compound
### AND the user is currently on the HOP fitness tab
############################ 
observeEvent(cmpRECVD(),{
    req(tabRECVD())
    req(cmpRECVD())

   # choices
   cmpSERV = cmpRECVD()
   # module cmp
   drugMOD = input$cmpMOD
    
   tabSERV = tabRECVD()
    
   notSYNC = drugMOD != cmpSERV
     
    ns <- session$ns
    req(tabSERV)
    req(length(tabSERV > 0))
    
    
    ### if compound received from the server then update the compound in the module
    
    if(tabSERV != "goenrich"){
      
      updateSelectizeInput(session, 'cmpMOD', choices = cmpSERV)

      updateSliderInput(session,'scorethreshMOD',label = "input score threshold", min = 0, max = 5,
                        value = 1, step = 0.5)
      updateSliderInput(session,'fdrMOD',label = "FDR threshold", min = 0, max = 0.5,
                        value = 0.1, step = 0.05)
     
    }
    
    
  },ignoreInit = F, ignoreNULL = T)
############################ IMPORTANTANT 
### updates the MODULE paramenters on any change;
### RETURNS the MODULE compound only the change occured on the GOENRICH fitness tab
############################ 
observeEvent(input$cmpMOD,{
    req(input$cmpMOD)
    req(reactive({tabs()}))
    req(cmpRECVD())
    tab = reactive({tabs()})
    
    
    ns <- session$ns 
    req(tabRECVD())
    updateSliderInput(session,'scorethreshMOD',label = "input score threshold", min = 0, max = 5,
                        value = 1, step = 0.5)
    updateSliderInput(session,'fdrMOD',label = "FDR threshold", min = 0, max = 0.5,
                        value = 0.1, step = 0.05)
    
    notSYNC = input$cmpMOD != cmpRECVD()
    tabMOD = tabRECVD() == "goenrich" 
    
    ### if cmp was changed from the MOD side, then send the compound back
    
    if(tabMOD & notSYNC){
        
        returnMOD$cmp = input$cmpMOD
        
        
        }

  },ignoreInit = F, ignoreNULL = T)
############################   

  
returnMOD = reactiveValues(cmp = NULL)
############################ 
  return(
    
      reactive({ returnMOD$cmp })
      
    )
  
}

