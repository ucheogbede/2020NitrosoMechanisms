mystrsplit = function(str,splt,index){
  xsplt = sapply(strsplit(str,splt), function(x) x = x[index])
  xsplt
  }

############
# generates parameters for drawing GO enrichment networks
# enrichInfo - dataframe with enrichment stats for gene sets (one per row), with the following columns:
#             filename, term, geneSetFraction, FDR, overlapGenes, maxOverlapGeneScore
#           - see documentation for the output of hyperG() for descriptions of these columns
#           - rows with the same value, x, in the filename column specify enrichment results for
#             the set of query genes in queryGeneSets with name=x
# edgeMat - dataframe of edge set info: id=gene set id, cluster=cluster id, es=enrichment score, fdr=FDR value
#
####
visSetup = function(enrichInfo, edgeMat) {
  
  library(igraph)
  library(visNetwork)
  n = enrichInfo
  e = edgeMat
  
  w = which(names(n) == "id")
  coln = ncol(n) - 1
  n = n[, c(w, 1:coln)]
  
  if (is.null(e) & !is.null(n)) {
    gr = make_empty_graph(nrow(enrichInfo))
    v = gr
    V(v)$color.background = n$cluster
    v = set_vertex_attr(v, "label", value = n$formattedLabel)
    
  }
  
  
  if (!is.null(e) & !is.null(n)) {
    w = which(names(e) == "label")
    let = graph_from_data_frame(e[, -w], vertices = n, directed = F)
    v = set_vertex_attr(let, "label", value = n$formattedLabel)
    V(v)$color.background = n$cluster
  }
  
  vis = toVisNetworkData(v)
  vis$nodes = data.frame(vis$nodes, stringsAsFactors = F)
  if (!is.null(vis$edges))
    vis$edges = data.frame(vis$edges, stringsAsFactors = F)
  m = match(vis$nodes$id, n$id)
  vis$nodes$label = n$formattedLabel[m]
  vis$nodes$FDR = n$FDR[m]
  vis$nodes$FDR = signif(vis$nodes$FDR, 4)
  
  vis$nodes =  vis$nodes %>% group_by(FDR) %>% mutate(jitter = if (n() > 1)
    abs(jitter(FDR))
    else
      (FDR)
  )
  
  w = which(names(vis$nodes) == "FDR")
  vis$nodes = vis$nodes[, -w]
  w = which(names(vis$nodes) == "jitter")
  names(vis$nodes)[w] = "FDR"
  vis$nodes$FDR = signif(vis$nodes$FDR, 4)
  w = which(duplicated(vis$nodes$FDR))
  if (length(w) > 0) {
    vis$nodes =  vis$nodes %>% group_by(FDR) %>% mutate(
      jitter = if (n() > 1)
        abs(jitter(FDR))
      else
        (FDR)
    )
    
    w = which(names(vis$nodes) == "FDR")
    vis$nodes = vis$nodes[, -w]
    w = which(names(vis$nodes) == "jitter")
    names(vis$nodes)[w] = "FDR"
    vis$nodes$FDR = signif(vis$nodes$FDR, 5)
  }
  
  w = which(duplicated(vis$nodes$FDR))
  #print(paste("dup",length(w)))
  vis$nodes$term = n$term[m]
  vis$nodes$nGenes = n$nGenes[m]
  vis$nodes$geneSetFraction = n$geneSetFraction[m]
  vis$nodes$formattedLabel = n$formattedLabel[m]
  vis$nodes$overlapGenes = n$overlapGenes[m]
  vis$nodes$label = vis$nodes$formattedLabel
  vis$nodes$color.border = "black"
  vis$nodes = vis$nodes %>% arrange(label)
  if (nrow(vis$edges) > 0)
    vis$edges$color = "black"
  
  vis$nodes$borderWidthSelected	= 4
  w = which(names(vis$nodes) %in% c("fomattedLabel", "color", "cluster"))
  if (length(w) > 0)  vis$nodes = vis$nodes[, -w]
  vis$nodes$color.highlight.border = "#000066"
  vis$nodes$color.highlight.background = "#c0b3ff"
  vis$nodes$color.hover.background = "#000066"
  vis$nodes$color.hover.border = "#c0b3ff"
  vis$nodes$font.face = "Courier"
  vis$nodes$shape = "dot"
  vis$nodes$font.size = 20
  vis$nodes$font.bold = F
  vis$nodes$borderWidth = 2
  #vis$nodes$vadjust = "mono"
  vis$nodes$borderWidthSelected = 4
  vis$nodes$labelHighlightBold = T
  w = which.min(vis$nodes$FDR)
  if (length(w) > 0) {
    vis$nodes$font.size[w] = 25
    vis$nodes$borderWidth[w] = 4
    vis$nodes$font.bold[w] = T
  }
  vis
  
}



############ GENE ANNOTATION
# generates annotation for the HOP fitness plots
# mat - data matrix; each colname is a screen. values are defect scores, rownames are gene names
# cmp = colnames
# sgdlink - provides link to SGD for gene names 
# out put is shown on the HOP fitness tap underneath the plots; used as input for the ggfit plots below
####

geneAnno <-  function(mat,fdat = NULL,cmp,sgdlink = TRUE, 
                        enrichtype = "fd",arrange = F, xvar = TRUE){
  
  mystrsplit = function(str,splt,index){
  xsplt = sapply(strsplit(str,splt), function(x) x = x[index])
  xsplt
  }
  
  if(is.null(fdat)) {
  fdat<-  read.delim("november24_fdata_updated.txt",
      stringsAsFactors = F,check.names = F)
          }

  mat = mat [order(rownames(mat)),]
  w1 = which(colnames(mat) %in% cmp)
  req(length(w1) > 0)
   validate(
      need(length(w1) == 1 ,message = 
          "please enter a valid compound"))
  
  dmat = data.frame(gene = rownames(mat),FD = mat[,w1],stringsAsFactors = F,check.names = F)
  if(arrange) dmat = dmat %>% arrange(desc(FD))
  #dmat$FD = as.numeric(dmat$FD)
  m = match(dmat$gene,fdat$sgd_gene)
  dmat[,c("ORF","descriptor")] = NA
  dmat[,c("ORF","descriptor")] = fdat[m,c("sgd_orf","descriptor")]
  
  if(sgdlink) {
    
    dmat$GENE = paste0("<a href=https://www.yeastgenome.org/locus/",dmat$gene,">",dmat$gene,"</a>")
  if(xvar) dmat$xvar = as.numeric(1:nrow(dmat))
    
  
    g = grep("_",dmat$gene)
    if(length(g) > 0)  s = mystrsplit(dmat$GENE[g],"_",1)
    if(length(g) > 0)  s2 = mystrsplit(s,"<a href=https://www.yeastgenome.org/locus/",2)
    if(length(g) > 0) dmat$GENE[g] = paste0(s,">",s2,"</a>")
  
  
  }

  if(xvar & sgdlink) {
    dmat = dmat[,c("xvar","FD","ORF","gene","GENE","descriptor")] } else {
  if(xvar) {  
      
       dmat[,c("xvar","FD","ORF","gene","descriptor")] }
    }
  
  #dmat$FD = round(dmat$FD,3)
  
  
  dmat
  
}

#############    HOP FITNESS PLOTS  #############
############# PARAMETERS:    hop = dataframe from geneanno function; ylimScreen from ylimits in app; sig = significant threshold from app
hopFit = function(hop,cmp, sigScreen = 2, ylimScreen = NULL){
  
  if(is.null(ylimScreen)) ylimScreen = c(-1,max(hop$FD,na.rm = T))
  
  
  w = which(hop$FD > sigScreen)
  hop$sigScreen = 0
  hop$sigScreen[w] = 1
  
  
  
  
  g  = ggplot(hop,aes(x =  gene,y=FD,col = factor(sigScreen))) + theme_bw() + ylim(ylimScreen[1],ylimScreen[2]) +
        geom_point(shape = 17,size = 6) 
        #scale_shape_manual(values = c(17))
  
  g1 = g + theme(legend.position="none") +
        theme(panel.grid.minor =   element_blank()) +
        theme(panel.grid.major = element_blank()) +
        theme(axis.ticks = element_blank(), axis.text.x =   element_blank())
  
  # g1 = g1 + 
  #         geom_hline(yintercept= sigScreen,color = "red",
  #           linetype = "dashed",size = 1) 
          
  
  g2 = g1 + geom_text_repel(size = 5, 
                            data = subset(hop, sigScreen == TRUE),
                            aes(x =  gene,y = FD, label = gene,fontface = 3),
                            point.padding = 0.45,
                            segment.color = NA, col = "black"
                            )
  g2 = g2 + labs(y = "fitness defect score") + ggtitle(cmp)
  
  g2 = g2 + theme(
                  axis.title=element_text(size = 20,face="bold"),
                  axis.text.y = element_text(face="bold",size = 16),
                  plot.title = element_text(size = 20,face = "bold"))
  g2 = g2 + scale_x_discrete(expand = expansion(add = 100))
  g2
  
}

#######
getLR = function(mat,ctrlI) {
  ctrlVal <- apply(mat[, ctrlI], 1, median, na.rm=T)
  
  lr <- sweep(-mat[, -ctrlI], 1, ctrlVal, "+")
}
###########
mymeltdf = function(mat, row, df = lphop){
  
  require(dplyr)
  mx = reshape2::melt(mat[row,], value.name = "fitness_defect")
  mx$gene = row
  mx$replicate_assays = rownames(mx)
  mx$fitness_defect = round(mx$fitness_defect,3)
  mx = mx[,c("gene","fitness_defect","replicate_assays")]
  m = match(mx$replicate_assays,df$name)
  table(is.na(m))
  mx$screen = df$screen[m]
  mx$count_matrix = df$counts[m]
  mx$drug = df$drug[m]
  mx$concentration = df$concentration[m]
  mx$replicate = df$replicate[m]
  
  #mx$compound = df$compound[m]
  #mx$pcid = df$pcid[m]
  mx$PCID = df$PCID[m]
  
  mx = mx %>% arrange(desc(fitness_defect),replicate)
  
  
  #mx = mx[,c("gene","fitness_defect","replicate_assays","drug","replicate","screen","PCID")]
  mx
  
}



###########
mycolors = c(
  "darkorange1",
  "dodgerblue",
  "darkgreen",
  "navy",
  "mediumpurple"  ,
  "royalblue3",
  "darkolivegreen4",
  "firebrick",
  "cyan4",
  "hotpink3",
  "plum4",
  "blue",
  "magenta4",
  "skyblue3",
  "green4",
  "red3",
  "steelblue3",
  "tomato",
  "purple4",
  "goldenrod3",
  "steelblue",
  "darkred",
  "lightpink3",
  "darkorchid",
  "lightblue3",
  "dimgrey",
  "chocolate1",
  "seagreen3",
  "darkkhaki",
  "darksalmon"
)

############

myscore = function(mat,column, sigScreen){
  library(dplyr)
  df = data.frame(score = mat[,column],stringsAsFactors = F)
  df$gene = rownames(mat)
  rownames(df) = df$gene
  df$index=0
  wdf = which(df$score > sigScreen)
  df$index[wdf]=1
  df = df[,c('index','score','gene')]
  df = df %>% arrange(desc(score))
  df
}
